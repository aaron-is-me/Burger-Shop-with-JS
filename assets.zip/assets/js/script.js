/**
 * navbar toggle
 */
const navbar = document.querySelector("[data-navbar]");
const navbarLinks = document.querySelectorAll("[data-nav-link]");
const menuToggleBtn = document.querySelector("[data-menu-toggle-btn]");

menuToggleBtn.addEventListener("click", function () {
  navbar.classList.toggle("active");
  this.classList.toggle("active");
});

navbarLinks.forEach(link => {
  link.addEventListener("click", function () {
    navbar.classList.toggle("active");
    menuToggleBtn.classList.toggle("active");
  });
});

/**
 * header sticky & back to top
 */
const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

window.addEventListener("scroll", function () {
  if (window.scrollY >= 100) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
});

/**
 * search box toggle
 */
const searchBtn = document.querySelector("[data-search-btn]");
const searchContainer = document.querySelector("[data-search-container]");
const searchSubmitBtn = document.querySelector("[data-search-submit-btn]");
const searchCloseBtn = document.querySelector("[data-search-close-btn]");

const searchBoxElems = [searchBtn, searchSubmitBtn, searchCloseBtn];

searchBoxElems.forEach(elem => {
  elem.addEventListener("click", function () {
    searchContainer.classList.toggle("active");
    document.body.classList.toggle("active");
  });
});

/**
 * move cycle on scroll
 */
const deliveryBoy = document.querySelector("[data-delivery-boy]");

let deliveryBoyMove = -80;
let lastScrollPos = 0;

window.addEventListener("scroll", function () {
  let deliveryBoyTopPos = deliveryBoy.getBoundingClientRect().top;

  if (deliveryBoyTopPos < 500 && deliveryBoyTopPos > -250) {
    let activeScrollPos = window.scrollY;

    if (lastScrollPos < activeScrollPos) {
      deliveryBoyMove += 1;
    } else {
      deliveryBoyMove -= 1;
    }

    lastScrollPos = activeScrollPos;
    deliveryBoy.style.transform = `translateX(${deliveryBoyMove}px)`;
  }
});

// Add to Cart
const listProductHTML = document.querySelector(".listProduct");
const listCartHTML = document.querySelector(".listCart");
const iconCart = document.querySelector(".icon-cart");
const iconCartSpan = document.querySelector(".icon-cart span");
const body = document.querySelector("body");
const closeCart = document.querySelector(".close");
const removeItemButton = document.querySelector(".removeItem");
const totalAmountHTML = document.querySelector("#totalAmount");

// Initialize app variables
let products = [];
let cart = [];

// Fetch and initialize product data
const initApp = () => {
    fetch("products.json")
        .then(response => response.json())
        .then(data => {
            products = data;
            addDataToHTML();

            // Load cart data from localStorage
            const savedCart = localStorage.getItem("cart");
            if (savedCart) {
                cart = JSON.parse(savedCart);
                updateCartHTML();
                updateTotalAmount(); // Update total amount on initial load
            }
        });
};

// Add products to the HTML
const addDataToHTML = () => {
    if (!listProductHTML) return; // Check if the product list exists on the page
    listProductHTML.innerHTML = ""; // Clear existing products

    // Add new products
    if (products.length > 0) {
        products.forEach(product => {
            let newProduct = document.createElement("div");
            newProduct.dataset.id = product.id;
            newProduct.classList.add("item");
            newProduct.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h2>${product.name}</h2>
                <div class="price">$${product.price}</div>
                <button class="addCart">Add To Cart</button>
            `;
            listProductHTML.appendChild(newProduct);
        });
    }
};

// Add product to cart
const addToCart = (product_id) => {
    const existingProductIndex = cart.findIndex(item => item.product_id === product_id);

    if (existingProductIndex < 0) {
        cart.push({ product_id: product_id, quantity: 1 });
    } else {
        cart[existingProductIndex].quantity += 1;
    }

    updateCartCount();
    saveCartToLocalStorage();
    updateCartHTML();
    updateTotalAmount(); // Update total amount after adding to cart
};

// Save cart to localStorage
const saveCartToLocalStorage = () => {
    localStorage.setItem("cart", JSON.stringify(cart));
};

// Update cart count in the icon
const updateCartCount = () => {
    const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
    iconCartSpan.textContent = totalQuantity;
};

// Update total amount in the UI
const updateTotalAmount = () => {
    const total = cart.reduce((sum, item) => {
        const product = products.find(p => p.id == item.product_id);
        return product ? sum + product.price * item.quantity : sum;
    }, 0);

    totalAmountHTML.textContent = `The total amount is $${total.toFixed(2)}`;
};

// Update cart items in the HTML
const updateCartHTML = () => {
    if (!listCartHTML) return; // Check if the cart list exists on the page
    listCartHTML.innerHTML = "";

    cart.forEach(item => {
        const product = products.find(p => p.id == item.product_id);
        if (!product) return;

        let newItem = document.createElement("div");
        newItem.classList.add("item");
        newItem.dataset.id = item.product_id;
        newItem.innerHTML = `
            <div class="image"><img src="${product.image}" alt="${product.name}"></div>
            <div class="name">${product.name}</div>
            <div class="totalPrice">$${product.price * item.quantity}</div>
            <div class="quantity">
                <span class="minus">&lt;</span>
                <span>${item.quantity}</span>
                <span class="plus">&gt;</span>
            </div>
        `;
        listCartHTML.appendChild(newItem);
    });
    updateCartCount();
    updateTotalAmount(); // Update total amount after updating cart
};

// Change quantity of items in the cart
const changeQuantityInCart = (product_id, type) => {
    const itemIndex = cart.findIndex(item => item.product_id === product_id);

    if (itemIndex >= 0) {
        if (type === "plus") {
            cart[itemIndex].quantity += 1;
        } else {
            cart[itemIndex].quantity -= 1;
            if (cart[itemIndex].quantity <= 0) {
                cart.splice(itemIndex, 1); // Remove item if quantity is 0
            }
        }
    }
    saveCartToLocalStorage();
    updateCartHTML();
    updateTotalAmount(); // Update total amount after changing quantity
};

// Event listeners
document.querySelector('.checkOut').addEventListener('click', function() {
    window.location.href = 'check.html'; // Redirect to checkout page
});

iconCart?.addEventListener("click", () => {
    body.classList.toggle("showCart");
});

closeCart?.addEventListener("click", () => {
    body.classList.toggle("showCart");
});

removeItemButton?.addEventListener("click", () => {
    listCartHTML.innerHTML = ""; // Clear cart items from HTML
    cart = []; // Reset cart array
    localStorage.removeItem("cart"); // Remove cart data from local storage
    updateCartCount(); // Update cart count in the UI
    updateTotalAmount(); // Update total amount in the UI
});

listProductHTML?.addEventListener("click", (event) => {
    if (event.target.classList.contains("addCart")) {
        const productId = event.target.parentElement.dataset.id;
        addToCart(productId);
    }
});

listCartHTML?.addEventListener("click", (event) => {
    if (event.target.classList.contains("minus") || event.target.classList.contains("plus")) {
        const productId = event.target.closest(".item").dataset.id;
        const type = event.target.classList.contains("plus") ? "plus" : "minus";
        changeQuantityInCart(productId, type);
    }
});

document.addEventListener("DOMContentLoaded", initApp);

/**
 * Table Booking
 */
const bookings = []; // Array to store bookings

document.getElementById("bookBtn")?.addEventListener("click", function (event) {
  event.preventDefault(); // Prevent form submission

  // Get user input for start and end times, and booking date
  const startTime = document.getElementById("start_time").value;
  const endTime = document.getElementById("end_time").value;
  const tableType = document.getElementById("table_type").value;
  const bookingDate = document.getElementById("booking_date").value; // Assume you have an input for booking date

  if (!startTime || !endTime || !tableType || !bookingDate) {
    alert("Please fill in all fields.");
    return;
  }

  // Convert times to Date objects for comparison, using the provided booking date
  const start = new Date(`${bookingDate}T${startTime}:00`);
  const end = new Date(`${bookingDate}T${endTime}:00`);

  // Check for time validity
  if (start >= end) {
    alert("End time must be later than start time.");
    return;
  }

  // Check for table availability only on the same date
  for (let i = 0; i < bookings.length; i++) {
    const booking = bookings[i];

    // Check if the booking date matches
    if (booking.date === bookingDate) {
      const bookingStart = new Date(`${booking.date}T${booking.startTime}:00`);
      const bookingEnd = new Date(`${booking.date}T${booking.endTime}:00`);

      // Check for overlapping times on the same date and table type
      if (
        tableType === booking.tableType &&
        ((start >= bookingStart && start < bookingEnd) ||
          (end > bookingStart && end <= bookingEnd))
      ) {
        alert("This table is not available for the selected time on this date.");
        return;
      }
    }
  }

  // Update displayed "Book From" and "To This" times
  document.getElementById("book_from").textContent = `Book From: ${startTime}`;
  document.getElementById("book_to").textContent = `To This: ${endTime}`;

  // If available, add booking to array
  bookings.push({ date: bookingDate, startTime, endTime, tableType });
  alert("Booking successful!");

  // Set a timeout to remove the booking after its end time passes
  const duration = end - new Date();
  if (duration > 0) {
    setTimeout(() => {
      removeBooking(bookingDate, startTime, endTime, tableType);
    }, duration);
  }
});

// Function to remove booking after end time passes
function removeBooking(bookingDate, startTime, endTime, tableType) {
  const index = bookings.findIndex(
    (booking) =>
      booking.date === bookingDate &&
      booking.startTime === startTime &&
      booking.endTime === endTime &&
      booking.tableType === tableType
  );

  if (index !== -1) {
    bookings.splice(index, 1);
  }
}
